#ifndef _HAPROXY_HQ_INTEROP_H_
#define _HAPROXY_HQ_INTEROP_H_

extern const struct qcc_app_ops hq_interop_ops;

#endif /* _HAPROXY_HQ_INTEROP_H_ */
